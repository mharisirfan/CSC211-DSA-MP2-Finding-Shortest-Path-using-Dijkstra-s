///**************************Muhammad Haris Irfan || FA18-BCE-090 ||(23-12-09)******************************************///
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "node.h"
#include "stack_functions.h"

#define NUM_VERTICES 10
   int visited[NUM_VERTICES];
   int carry=0;
    int smallest=999;
    int value=0;

/** This function takes a pointer to the
    adjacency matrix of a Graph and the
    size of this matrix as arguments and
    prints the matrix
*/
void print_graph(int * graph, int size);

/** This function takes a pointer to the
    adjacency matrix of a Graph, the size
    of this matrix, the source and dest
    node numbers along with the weight or
    cost of the edge and fills the adjacency
    matrix accordingly.
*/
void add_edge(int * graph, int size, int src, int dst, int cost);

/** This function takes a pointer to the adjacency matrix of
    a graph, the size of this matrix, source vertex number
    and a pointer to an array for holding the computed shortest
    distances as arguments.
*/
void find_shortest_paths( int * graph, int size, int src, int * dist_array);

int main()
{
    int my_graph[NUM_VERTICES][NUM_VERTICES];   /// An adjacency matrix representation of graph
    memset(my_graph,-1,NUM_VERTICES * NUM_VERTICES * sizeof(int));     /// Initiallize with -1 representing infinte cost.

     int userin;
    for(int i=0; i<NUM_VERTICES; i++)
        add_edge(&my_graph[0][0], NUM_VERTICES, i, i, 0);

    add_edge(&my_graph[0][0], NUM_VERTICES, 0, 3, 13);
    add_edge(&my_graph[0][0], NUM_VERTICES, 1, 4, 14);
    add_edge(&my_graph[0][0], NUM_VERTICES, 1, 5, 6);
    add_edge(&my_graph[0][0], NUM_VERTICES, 2, 3, 9);
    add_edge(&my_graph[0][0], NUM_VERTICES, 2, 9, 10);
    add_edge(&my_graph[0][0], NUM_VERTICES, 3, 0, 13);
    add_edge(&my_graph[0][0], NUM_VERTICES, 3, 8, 9);
    add_edge(&my_graph[0][0], NUM_VERTICES, 4, 1, 14);
    add_edge(&my_graph[0][0], NUM_VERTICES, 4, 6, 8);
    add_edge(&my_graph[0][0], NUM_VERTICES, 5, 1, 6);
    add_edge(&my_graph[0][0], NUM_VERTICES, 5, 2, 7);
    add_edge(&my_graph[0][0], NUM_VERTICES, 5, 6, 12);
    add_edge(&my_graph[0][0], NUM_VERTICES, 6, 4, 8);
    add_edge(&my_graph[0][0], NUM_VERTICES, 6, 7, 15);
    add_edge(&my_graph[0][0], NUM_VERTICES, 7, 6, 15);
    add_edge(&my_graph[0][0], NUM_VERTICES, 8, 5, 11);
    add_edge(&my_graph[0][0], NUM_VERTICES, 9, 8, 23);

    print_graph(&my_graph[0][0], NUM_VERTICES);


    int shortest_dists[NUM_VERTICES];

    for(int i=0; i<NUM_VERTICES; i++)
    {
        shortest_dists[i] = -1;
    }
    printf("\n Enter Your Source node from 0-9?");   /// To Enable user to Fix any node as source node.
    scanf("%d",&userin);

    find_shortest_paths(&my_graph[0][0], NUM_VERTICES, userin, shortest_dists);

    printf("\n Cost to vertices: ");
    for(int i=0; i<NUM_VERTICES; i++)
    {
        printf("\t%d", shortest_dists[i]);
    }
    printf("\n");
    getchar();
    return 0;
}

void add_edge(int * graph, int size, int src, int dst, int cost)
{
    *(graph+(src*size+dst)) = cost;
}

void print_graph(int * graph, int size)
{
    //char vertices[size];
    for(int i=0; i<size; i++)
    {
        //vertices[i] = 'A'+i;
        //printf("\t%c", vertices[i]);
        printf("\t%d", i);
    }
    printf("\n\n");
    for(int x=0; x<size; x++)
    {
        //printf("%c\t", vertices[x]);
        printf("%d\t", x);
        for(int y=0; y<size; y++)
            printf("%d\t", *(graph+(x*size+y)));
        printf("\n");
    }
}


void find_shortest_paths( int * graph, int size, int src, int * dist_array)
{

    /*** Complete this function ***/
int num;

if (value==0) /// value is globally declared and initially set to 0, after all the neighbouts of source are done, it is set to 1 so that the next time code skips this part.
{

    for(int x=src;x<src+1;x++)
    {
        for(int y=0;y<size;y++)
        {
            if(*(graph+(x*size+y))!= -1)  /// looking for neighbors, (-1) means not a neighbor
            {

                *(dist_array+y)=*(graph+(x*size+y));
            }
        }
        visited[x]=1;                   /// adding the value to visited array
    }

    for(int j=0;j<size;j++)       /// this loop is to find the smallest value that will be checked.. this will return the smallest cost
    {
        if (*(dist_array+j)< smallest && *(dist_array+j)!= -1 && *(dist_array+j)!= 0 && visited[j]!=1)
        {
            smallest=*(dist_array+j);   //'smallest' is the least cost in distance array that is not visited not is infinity
        }
    }

    for(int k=0;k<size;k++) ///this loop is to find the node from the smallest value already found.
{
         num=k;
         if(*(dist_array+k)==smallest)
         {
             num=k;  ///here k will have the node number against which the smallest value is saved...to be used for next traversal.
            break;
         }

}
carry=carry+smallest;  /// carry is updated.. carry is the path cost that is carried from the source node
int carryvalu2=carry;/// /for debugging
int numvalue=num;/// for debugging
value++;

    if (visited[num]!=1)  ///becuz we dont wanna put a number that is already visited
    find_shortest_paths(graph, NUM_VERTICES, num, dist_array);

}

/// AFTER the first time, the recursive calls will land here and the code below will work,all traversals after the first.

int carryvalu3=0;///for debugging
 for(int x=src;x<src+1;x++)
    {
        for(int y=0;y<size;y++)
        {
            if(*(graph+(x*size+y))!= -1  && ((*(dist_array+y)> (*(graph+(x*size+y))+carry) )|| *(dist_array+y)==-1))
            {
                    carryvalu3=carry+ *(graph+(x*size+y));///for debugging
                *(dist_array+y)=carry+ *(graph+(x*size+y));
            }
        }
        visited[x]=1;  ///marked visited
    }
smallest =999; ///globally declared, a large value just for comparison.
  for(int j=0;j<size;j++)
    {
        if (*(dist_array+j)< smallest && *(dist_array+j)!= -1 && *(dist_array+j)!= 0 && visited[j]!=1)
        {
            smallest=*(dist_array+j);
        }
    }
    for(int k=0;k<size;k++)
{
         num=k;
         if(*(dist_array+k)==smallest)
         {
             num=k;
             carry=0;
            break;
         }
}
carry=carry+smallest;

int numvalue3=num;/// for debugging

    if (visited[num]!=1)    ///the program terminates when all the numbers are added in the visited array
    find_shortest_paths(graph, NUM_VERTICES, num, dist_array);

}
///**************************Muhammad Haris Irfan || FA18-BCE-090 ||(23-12-09)******************************************///
